import os
import shutil
from PIL import Image
from sklearn.model_selection import train_test_split

# -------------------------------
# Replace this with your dataset folder name
dataset_dir = "PlantVillage"
# -------------------------------

classes = ["healthy", "diseased"]
corrupt_dir = os.path.join(dataset_dir, "corrupt_images")
os.makedirs(corrupt_dir, exist_ok=True)

# Folders for train and validation
train_dir = os.path.join(dataset_dir, "train")
val_dir = os.path.join(dataset_dir, "validation")

for folder in [train_dir, val_dir]:
    for cls in classes:
        os.makedirs(os.path.join(folder, cls), exist_ok=True)

# 1️⃣ Verify images and resize
valid_images = {cls: [] for cls in classes}

for cls in classes:
    class_path = os.path.join(dataset_dir, cls)
    for img_file in os.listdir(class_path):
        img_path = os.path.join(class_path, img_file)
        try:
            img = Image.open(img_path)
            img.verify()  # check corruption
            img = Image.open(img_path)  # reopen for resizing
            img = img.resize((128, 128))
            img.save(img_path)
            valid_images[cls].append(img_file)
        except:
            print(f"Corrupt image: {img_path}")
            shutil.move(img_path, os.path.join(corrupt_dir, img_file))

# 2️⃣ Split into train and validation
for cls in classes:
    train_files, val_files = train_test_split(valid_images[cls], test_size=0.2, random_state=42)
    
    for file in train_files:
        src = os.path.join(dataset_dir, cls, file)
        dst = os.path.join(train_dir, cls, file)
        shutil.copy(src, dst)
    
    for file in val_files:
        src = os.path.join(dataset_dir, cls, file)
        dst = os.path.join(val_dir, cls, file)
        shutil.copy(src, dst)

print("Dataset verification, resizing, and split completed!")
print(f"Train folder: {train_dir}")
print(f"Validation folder: {val_dir}")
print(f"Corrupt images moved to: {corrupt_dir}")