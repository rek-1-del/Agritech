# predict_small.py
# Loads the trained model and predicts on one test image.

import tensorflow as tf
import numpy as np
from tensorflow import keras
from tensorflow.keras.preprocessing import image
import os

# Path to saved model
MODEL_PATH = r"C:\Users\vasav\agrizen-backend\model_small.keras"

model = keras.models.load_model(MODEL_PATH)

# Classes (must match training order)
class_names = ['bacterial', 'fungal', 'healthy']

# Pick a test image (change filename if needed)
img_path = r"C:\Users\vasav\agrizen-backend\data\test\healthy\healthy_001.jpg"

# Load and preprocess
img = image.load_img(img_path, target_size=(160,160))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = tf.keras.applications.mobilenet_v2.preprocess_input(x)

# Prediction
preds = model.predict(x)
pred_class = class_names[np.argmax(preds)]
confidence = float(np.max(preds))

print("Prediction:", pred_class, "| Confidence:", round(confidence,2))
