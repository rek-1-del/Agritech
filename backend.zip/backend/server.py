# server.py
import os, sqlite3, datetime, base64
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
from flask_cors import CORS

# ---- AI model loader & helper ----
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow import keras

MODEL_PATH = r"C:\Users\vasav\agrizen-backend\model_small.keras"
IMG_SIZE = (160, 160)

model_obj = None
class_names = []

try:
    model_obj = keras.models.load_model(MODEL_PATH)
    train_dir = r"C:\Users\vasav\agrizen-backend\data\train"
    if os.path.isdir(train_dir):
        class_names = sorted([d for d in os.listdir(train_dir) if os.path.isdir(os.path.join(train_dir, d))])
    else:
        class_names = ['bacterial', 'fungal', 'healthy']
    print("AI model loaded. Classes:", class_names)
except Exception as e:
    model_obj = None
    print("Warning: could not load AI model at", MODEL_PATH, "\nError:", e)


def predict_image_file(image_path):
    """Run prediction on a saved image file using the loaded AI model."""
    if model_obj is None:
        return ("model-not-loaded", 0.0)

    img = Image.open(image_path).convert('RGB')
    img = img.resize(IMG_SIZE)
    arr = np.array(img, dtype=np.float32)
    arr = np.expand_dims(arr, axis=0)
    arr = tf.keras.applications.mobilenet_v2.preprocess_input(arr)

    preds = model_obj.predict(arr)
    idx = int(np.argmax(preds, axis=-1)[0])
    confidence = float(np.max(preds))
    label = class_names[idx] if idx < len(class_names) else str(idx)
    return (label, confidence)


# ---- Flask app and DB ----
UPLOAD_FOLDER = "uploads"
DB_FILE = "submissions.db"
ALLOWED_IMAGE_EXT = {"png", "jpg", "jpeg", "webp"}
ALLOWED_AUDIO_EXT = {"wav", "mp3", "webm", "ogg"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
CORS(app)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def add_submission(input_type, filename, text_content, phone, consent, status, diagnosis, confidence):
    conn = get_db()
    c = conn.cursor()
    c.execute('''
      INSERT INTO submissions (input_type, filename, text_content, phone, consent, status, diagnosis, confidence, created_at)
      VALUES (?,?,?,?,?,?,?,?,?)
    ''', (input_type, filename, text_content, phone, int(bool(consent)), status, diagnosis, confidence,
          datetime.datetime.utcnow().isoformat()))
    conn.commit()
    sid = c.lastrowid
    conn.close()
    return sid


def allowed_file(filename, allowed_set):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_set


# ---- Routes ----
@app.route('/api/diagnose', methods=['POST'])
def diagnose():
    input_type = request.form.get('inputType', 'image')
    phone = request.form.get('phone')
    consent = request.form.get('consent') == 'on' or request.form.get('consent') == 'true'
    text_content = None
    filename_saved = None
    diagnosis = "Unknown"
    confidence = 0.0
    status = "received"

    if input_type == 'image':
        file = request.files.get('photo')
        if not file or file.filename == "":
            return jsonify({"error": "No image provided"}), 400
        if not allowed_file(file.filename, ALLOWED_IMAGE_EXT):
            return jsonify({"error": "Unsupported image type"}), 400
        fname = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S_") + secure_filename(file.filename)
        path = os.path.join(app.config['UPLOAD_FOLDER'], fname)
        file.save(path)
        filename_saved = fname

        # Use real AI predictor
        diagnosis, confidence = predict_image_file(path)
        print(f"[diagnose] image -> {diagnosis} (conf={confidence:.2f})")

        status = "auto-diagnosed" if confidence >= 0.5 else "needs-expert"

    elif input_type == 'text':
        text_content = request.form.get('symptom_text', '').strip().lower()
        if not text_content:
            return jsonify({"error": "No symptom text provided"}), 400

        # keyword-based rules
        fungal_keys = ["white powder", "powdery", "mildew", "mold", "spores", "brown edge", "brown edges", "spots", "leaf spots"]
        bacterial_keys = ["ooze", "sticky", "bacterial", "wilting", "wilt", "water soaked", "brown rot", "soft rot"]
        nutrient_keys = ["yellow", "chlorosis", "pale", "stunted", "necrosis", "interveinal", "purple veins"]
        healthy_keys = ["healthy", "no symptoms", "no visible", "green"]

        score = {"fungal":0, "bacterial":0, "nutrient":0, "healthy":0}
        for k in fungal_keys:
            if k in text_content:
                score["fungal"] += 1
        for k in bacterial_keys:
            if k in text_content:
                score["bacterial"] += 1
        for k in nutrient_keys:
            if k in text_content:
                score["nutrient"] += 1
        for k in healthy_keys:
            if k in text_content:
                score["healthy"] += 1

        best = max(score, key=score.get)
        best_score = score[best]

        if best == "nutrient":
            diagnosis = "nutrient-deficiency-suspected"
            confidence = 0.55 if best_score >= 1 else 0.35
        elif best == "healthy":
            diagnosis = "healthy"
            confidence = 0.85 if best_score >= 1 else 0.4
        elif best == "fungal":
            diagnosis = "fungal"
            confidence = 0.7 if best_score >= 1 else 0.4
        elif best == "bacterial":
            diagnosis = "bacterial"
            confidence = 0.7 if best_score >= 1 else 0.4
        else:
            diagnosis = "unsure-text"
            confidence = 0.25

        if best_score == 0 or list(score.values()).count(best_score) > 1:
            diagnosis = "unsure-text"
            confidence = 0.25

        status = "auto-diagnosed" if confidence >= 0.5 else "needs-expert"

   

    elif input_type == 'voice':
        dataurl = request.form.get('voice_blob')
        if not dataurl:
            return jsonify({"error": "No voice data"}), 400
        if ',' in dataurl:
            header, b64 = dataurl.split(',', 1)
        else:
            b64 = dataurl
        try:
            raw = base64.b64decode(b64)
            fname = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S_") + "voice.webm"
            path = os.path.join(app.config['UPLOAD_FOLDER'], fname)
            with open(path, "wb") as f:
                f.write(raw)
            filename_saved = fname

            # Placeholder voice logic
            diagnosis, confidence = ("unsure-voice", 0.25)
            status = "needs-expert"
            print(f"[diagnose] voice saved -> {path}")
        except Exception as e:
            return jsonify({"error": "Invalid voice data"}), 400

    sid = add_submission(input_type, filename_saved, text_content, phone, consent, status, diagnosis, confidence)

    return jsonify({
        "submission_id": sid,
        "status": status,
        "diagnosis": diagnosis,
        "confidence": confidence
    })


@app.route('/api/request-expert', methods=['POST'])
def request_expert():
    input_type = request.form.get('inputType', 'image')
    phone = request.form.get('phone')
    consent = request.form.get('consent') == 'on' or request.form.get('consent') == 'true'
    text_content = request.form.get('symptom_text')
    filename_saved = None

    if input_type == 'image':
        file = request.files.get('photo')
        if file:
            fname = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S_") + secure_filename(file.filename)
            path = os.path.join(app.config['UPLOAD_FOLDER'], fname)
            file.save(path)
            filename_saved = fname

    if input_type == 'voice':
        dataurl = request.form.get('voice_blob', '')
        if ',' in dataurl:
            header, b64 = dataurl.split(',', 1)
        else:
            b64 = dataurl
        raw = base64.b64decode(b64)
        fname = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S_") + "voice.webm"
        path = os.path.join(app.config['UPLOAD_FOLDER'], fname)
        with open(path, "wb") as f:
            f.write(raw)
        filename_saved = fname

    sid = add_submission(input_type, filename_saved, text_content, phone, consent,
                         "expert_requested", "pending", 0.0)
    return jsonify({"submission_id": sid, "status": "expert_requested"})


@app.route('/api/pending', methods=['GET'])
def pending():
    ADMIN_KEY = os.environ.get("ADMIN_KEY", "secret123")
    if request.headers.get('x-admin-key') != ADMIN_KEY:
        return jsonify({"error": "unauthorized"}), 401
    conn = get_db()
    items = conn.cursor().execute(
        "SELECT * FROM submissions WHERE status != 'reviewed' ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    result = [dict(r) for r in items]
    return jsonify(result)


@app.route('/api/expert-action', methods=['POST'])
def expert_action():
    ADMIN_KEY = os.environ.get("ADMIN_KEY", "secret123")
    if request.headers.get('x-admin-key') != ADMIN_KEY:
        return jsonify({"error": "unauthorized"}), 401
    sid = request.form.get('submission_id')
    notes = request.form.get('notes', '')
    diagnosis = request.form.get('diagnosis', '')
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE submissions SET status=?, expert_notes=?, diagnosis=?, confidence=? WHERE id=?",
              ("reviewed", notes, diagnosis, 1.0, sid))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


# ---- Main ----
if __name__ == "__main__":
    if not os.path.exists(DB_FILE):
        print("DB not found. Run db_init.py or it will be created automatically.")
    app.run(host="0.0.0.0", port=5000, debug=True)
