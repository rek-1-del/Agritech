# train_small.py
# Very small transfer-learning training using TensorFlow and MobileNetV2.
# Expects images under:
#   data/train/<class>  and data/val/<class>
# This script does a very short run (2 epochs) so you can see it works.

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import os

BASE_DIR = r"C:\Users\vasav\agrizen-backend\data"
BATCH_SIZE = 8
IMG_SIZE = (160, 160)   # small for speed
EPOCHS = 2              # short run for testing

train_dir = os.path.join(BASE_DIR, "train")
val_dir = os.path.join(BASE_DIR, "val")

print("Train dir:", train_dir)
print("Val dir:", val_dir)

# Create datasets from folders
train_ds = tf.keras.preprocessing.image_dataset_from_directory(
    train_dir,
    labels="inferred",
    label_mode="categorical",
    batch_size=BATCH_SIZE,
    image_size=IMG_SIZE,
    shuffle=True,
    seed=123
)

val_ds = tf.keras.preprocessing.image_dataset_from_directory(
    val_dir,
    labels="inferred",
    label_mode="categorical",
    batch_size=BATCH_SIZE,
    image_size=IMG_SIZE,
    shuffle=False
)

class_names = train_ds.class_names
num_classes = len(class_names)
print("Classes:", class_names)

# Prefetch / performance
AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.cache().prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)

# Build model: MobileNetV2 base + small head
base_model = tf.keras.applications.MobileNetV2(input_shape=IMG_SIZE + (3,),
                                               include_top=False,
                                               weights='imagenet')
base_model.trainable = False  # freeze for quick test

inputs = keras.Input(shape=IMG_SIZE + (3,))
x = tf.keras.applications.mobilenet_v2.preprocess_input(inputs)
x = base_model(x, training=False)
x = layers.GlobalAveragePooling2D()(x)
x = layers.Dropout(0.2)(x)
outputs = layers.Dense(num_classes, activation='softmax')(x)
model = keras.Model(inputs, outputs)

model.compile(optimizer=keras.optimizers.Adam(learning_rate=1e-3),
              loss='categorical_crossentropy',
              metrics=['accuracy'])

model.summary()

# Train (very short)
history = model.fit(train_ds,
                    validation_data=val_ds,
                    epochs=EPOCHS)

# Save the model (Keras .h5)
   # saves as a folder, not .h5
# Save the model in Keras v3 format
out_path = os.path.join(r"C:\Users\vasav\agrizen-backend", "model_small.keras")
model.save(out_path)   # saves as model_small.keras file
print("Saved model to:", out_path)


