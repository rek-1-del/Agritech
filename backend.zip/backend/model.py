# model.py
from PIL import Image
import random
import numpy as np

def mock_predict_image(image_path):
    """Very simple demo: open image and return a fake label."""
    try:
        img = Image.open(image_path).convert("RGB")
        arr = np.array(img.resize((64,64)))
        # a fake "score" from the image (just randomness here)
        score = random.random()
        if score < 0.4:
            return ("Healthy", float(score))
        elif score < 0.75:
            return ("Possible Fungal Infection", float(score))
        else:
            return ("Likely Bacterial Disease", float(score))
    except Exception as e:
        return ("Unknown", 0.0)

def mock_predict_text(text):
    text = (text or "").lower()
    if "yellow" in text or "wilting" in text:
        return ("Nutrient deficiency (suspected)", 0.6)
    if "spots" in text or "rust" in text:
        return ("Possible fungal spot", 0.65)
    return ("Needs expert review", 0.3)

def mock_predict_voice(voice_path):
    # For demo, we don't do speech->text here. Mark for review.
    return ("Needs expert review (voice)", 0.25)
