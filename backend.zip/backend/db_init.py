import sqlite3
import os

DB_FILE = "submissions.db"

def init_db():
    if os.path.exists(DB_FILE):
        print("DB already exists:", DB_FILE)
        return
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        input_type TEXT,
        filename TEXT,
        text_content TEXT,
        phone TEXT,
        consent INTEGER,
        status TEXT,
        diagnosis TEXT,
        confidence REAL,
        expert_notes TEXT,
        created_at TEXT
    )
    ''')
    conn.commit()
    conn.close()
    print("DB created:", DB_FILE)

if __name__ == "__main__":
    init_db()
